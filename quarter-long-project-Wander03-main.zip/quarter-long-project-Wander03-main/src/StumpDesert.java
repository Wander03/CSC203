import processing.core.PImage;

import java.util.List;

public class StumpDesert extends Stump{

    public StumpDesert(String id,
                       Point position,
                       List<PImage> images)
    {
        super(id, position, images);
    }

}
